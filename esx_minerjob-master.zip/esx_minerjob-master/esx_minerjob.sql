INSERT INTO `jobs` (name, label) VALUES
	('miner', 'Miner')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('miner', 0, 'employee', 'Employee', 0, '{}', '{}')
;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('stones', 'Stones', 40),
	('washedstones', 'Washed stones', 40),
	('diamond', 'Diamond', 100),
	('gold', 'Gold', 100),
	('iron', 'Iron', 100),
	('copper', 'Diamond', 100)
;
