Config = {}
Config.Locale = 'pl'

Config.CloakroomX = -287.18
Config.CloakroomY = 2535.58
Config.CloakroomZ = 75.47

Config.WashingX = 1916.2
Config.WashingY = 582.44
Config.WashingZ = 176.37

Config.RemeltingX = 1109.03
Config.RemeltingY = -2007.61
Config.RemeltingZ = 30.94

Config.SellX = -621.43
Config.SellY = -230.4
Config.SellZ = 37.05

Config.DiamondPrice = 1000
Config.GoldPrice = 150
Config.IronPrice = 50
Config.CopperPrice = 25
