# FiveM - Miner job for ESX

**The script adds a miner's job to FiveM. It has nothing to do with a standard miner job.**

